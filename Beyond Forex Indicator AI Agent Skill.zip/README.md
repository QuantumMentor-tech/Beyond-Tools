# AI Trade Strategy 04: Best Candidate From Strategies 01-03

Goal requested:

```text
At least 5 trades in the last week
At least 80% win rate
```

This candidate met the target on the tested sample.

Important: this was optimized on the same last-week data. That means it may be overfit. It must be tested on future/out-of-sample data before it should be trusted.

## Strategy Rules

Pairs:

- USDJPY
- USDCAD

Timeframe:

- Entry chart: 15-minute
- Trend/context chart: 1-hour

Core ideas combined:

- Trend filter
- Fibonacci pullback area
- Liquidity sweep
- Rejection candle
- Tight invalidation stop
- Small target for higher win rate

Mechanical settings:

```text
HTF: 1H
EMA trend: 10 EMA
Swing lookback: 6 HTF candles
Fibonacci zone: 23.6% to 88.6%
Liquidity sweep lookback: 5 candles
Require liquidity sweep: yes
Require rejection candle: yes
Stop: trigger candle high/low plus 0.05 ATR buffer
Target: 0.5R
Session: all day
```

Long logic:

1. 1H close is above rising 10 EMA.
2. 15M price is inside the pullback zone of the recent 1H swing.
3. Price sweeps the prior 5-candle low.
4. Candle closes bullish/rejects lower prices.
5. Enter long at close.
6. Stop below trigger candle low plus ATR buffer.
7. Target 0.5R.

Short logic:

1. 1H close is below falling 10 EMA.
2. 15M price is inside the pullback zone of the recent 1H swing.
3. Price sweeps the prior 5-candle high.
4. Candle closes bearish/rejects higher prices.
5. Enter short at close.
6. Stop above trigger candle high plus ATR buffer.
7. Target 0.5R.

## Last 1-Week Backtest Result

Data coverage:

```text
USDJPY: 2026-04-29 02:15 UTC -> 2026-05-07 20:00 UTC
USDCAD: 2026-04-29 02:15 UTC -> 2026-05-07 20:00 UTC
```

Total:

```text
Trades: 20
Wins: 18
Losses: 2
Win rate: 90.0%
Net R before spread: +7.00R
Net R after estimated spread: +3.73R
```

Pair summary:

```text
USDJPY: 10 trades, 9 wins, 1 loss, 90.0%, +2.55R after spread
USDCAD: 10 trades, 9 wins, 1 loss, 90.0%, +1.18R after spread
```

## Files

- `beyond_forex_tradingview_indicator.pine`: TradingView indicator for future chart signals.
- `run_strategy_04_best_candidate.py`: clean runner for the selected candidate.
- `search_best_combo_strategy.py`: broader search script used to test candidate variations.

## TradingView Setup

1. Open TradingView.
2. Open Pine Editor.
3. Paste `beyond_forex_tradingview_indicator.pine`.
4. Save it as `Beyond Forex`.
5. Add it to the chart.
6. Use it mainly on the 15-minute chart.
7. Keep the tested-pair filter on if you only want signals for USDJPY and USDCAD.

Default indicator settings match the tested Strategy 04 candidate:

```text
Trend timeframe: 1H
EMA length: 10
Swing lookback: 6
Fib zone: 0.236 to 0.886
Liquidity lookback: 5 candles
Stop buffer: 0.05 ATR
Target: 0.5R
```

## Honest Read

This is the first candidate that satisfies the requested condition. It is high win-rate because it uses a small `0.5R` target, which means it takes profits quickly.

The trade-off:

- High win rate
- Smaller reward per win
- More sensitive to spread and slippage

Before using this live, test it on at least 3-6 months of data and then forward-test it.
