# Prompt 1 — Cinematic 3D Website Challenge

## Objective

Build a single-page, scroll-driven website about a **next-generation 65mm large-format film camera**. The camera is the centerpiece: a photoreal 3D object that visitors can explore, watch disassemble into an exploded view while scrolling, see reassemble, and finally operate by pointing it toward a live cinematic scene and recording a shot.

Everything must be created in code.

The camera should not merely be recognizable. It should look as close as possible to a real photographed machine rendered in real time, with the visual quality of a modern high-end cinematic experience. Do not stop at a rough prototype.

---

## Your role

Act as a world-class creative front-end engineer and real-time 3D specialist.

Use a modern browser-based 3D rendering stack with native ES modules and no build step. Build the camera and its geometry procedurally from primitives.

Do not use:

- Imported 3D models
- Image textures
- Prebuilt environment maps
- Stock imagery
- Proprietary logos
- Branded markings
- Copied industrial-design assets

Open-source rendering, scrolling, interface, and post-processing utilities may be used, but the camera, its parts, geometry, and materials must be built in code.

---

## The camera

Create a plausible, mechanically convincing **carbon-fiber-bodied large-format film camera**. It should feel like a real precision-built cinema device rather than a generic science-fiction prop.

Build it from separable, named components so each part can move independently during the exploded-view sequence.

### Required components

1. **Carbon-fiber main body**
   - Compact, boxy, and refined
   - Procedural woven carbon-fiber panels
   - Panel seams
   - Recessed hex screws
   - Vents
   - Matte finish
   - Beveled and chamfered edges

2. **Large central lens assembly**
   - Substantial large-format prime lens
   - Professional cinema-style mount
   - Focus and iris rings
   - Barrel markings
   - Convincing front glass
   - Matte box with adjustable flags

3. **Film magazine and transport**
   - Reloadable large-format film chamber mounted on the upper or rear body
   - Approximately three minutes of film capacity per load
   - Visible film path and gate
   - Film moving horizontally through the transport
   - Film speed tied subtly to interaction or scroll

4. **Digital telemetry screen**
   - Body-mounted emissive display
   - Live-looking readouts for:
     - Frame rate
     - Film remaining
     - Temperature
     - Voltage
     - Current
     - Direction or transport status
   - Crisp anti-aliased text
   - Subtle panel glow

5. **Reflex viewfinder**
   - Mounted near the top-right area
   - Small video-monitoring module
   - Cables and mounting hardware

6. **Acoustic housing**
   - A large soundproof enclosure into which the camera lowers
   - Visually communicates extreme weight and scale
   - Includes structural supports and heavy-duty mounting points

7. **Twin-mirror viewing arm**
   - Mounts beside the lens
   - Uses two mirrors to redirect the viewing path
   - Includes an animated light or sightline demonstrating the reflection path

### Mechanical detailing

Add cables, ports, labels, a recording tally light, rod mounts, a top handle, fasteners, switches, connectors, vents, panel gaps, and small machined details.

The camera must look engineered, used, and physically plausible.

---

## Photorealism requirements

Every item below is mandatory.

### Materials

Use physically based metallic-roughness materials:

- Procedural carbon-fiber weave with generated albedo, roughness, and normal detail
- Anodized and brushed metal fittings
- Physically convincing transmissive lens glass
- Rubber grips
- Painted markings
- Matte and semi-gloss coated surfaces

### Lighting and reflections

- Generate a procedural high-dynamic-range studio environment
- Use physically correct key, fill, and rim lighting
- Preserve realistic reflections on metal and lens glass
- Use crisp contact shadows and self-shadowing
- Add ambient occlusion inside seams, gaps, and screw recesses
- Use screen-space reflections where supported

### Post-processing

Include:

- Filmic tone mapping
- Controlled bloom on the display and rim lights
- Depth of field with realistic bokeh
- Very subtle chromatic aberration
- Fine film grain
- Correct linear and display color management

### Geometry quality

- No razor-sharp computer-generated edges
- Use bevels and chamfers
- Maintain consistent panel gaps
- Use sufficient tessellation on curved parts
- Ensure the model survives slow close-up inspection

### Micro-detail

Add subtle:

- Edge wear
- Fine scratches
- Dust
- Fingerprints on metal and glass
- Film-emulsion sheen
- Visible film perforations
- Small manufacturing inconsistencies

These imperfections should be restrained. The goal is photographic realism, not damage.

### Realism in every state

The quality bar must remain consistent when:

- The camera is fully assembled
- Components are floating in the exploded view
- The camera enters the acoustic housing
- The mirror arm is attached
- The camera is operated in the finale

Each separated part must retain its full materials, reflections, ambient occlusion, shadows, and depth-of-field behavior.

---

## Scroll experience

Use a vertical large-format film strip as the visual scroll motif. The film strip may run beside the content or pass through the camera gate. Scrolling should feel like advancing film through a transport.

### Section 1 — Hero

Show the fully assembled camera rotating slowly against a near-black background with shallow depth of field.

Headline:

**THE LARGE-FORMAT CAMERA**

Subheading:

**A machine built to capture cinema at its largest scale.**

### Section 2 — The format

Center the camera and animate film threading through the magazine and gate.

On-screen copy:

**Fifteen-perforation large-format film moves more than five feet every second. Its scale creates extraordinary image detail—and extraordinary mechanical noise.**

Tie the film speed subtly to scroll progress.

### Section 3 — Exploded view

As the user scrolls, separate the camera into individually labeled parts.

Reveal one component at a time:

- Carbon-fiber body
- Film magazine
- Film transport and gate
- Lens assembly
- Telemetry display
- Reflex viewfinder
- Monitoring module

Each part must have:

- A thin leader line
- A concise label
- A practical specification
- A hover state that highlights it and dims unrelated components

### Section 4 — The noise problem

Reassemble the camera and lower it into the soundproof acoustic housing.

On-screen copy:

**Large-format film moves fast, and fast film is loud. The solution is a heavy acoustic enclosure engineered to make dialogue recording possible.**

Show the scale and weight visually.

### Section 5 — The mirror solution

Attach the twin-mirror arm beside the lens.

Animate a sightline bouncing through both mirrors.

On-screen copy:

**When the acoustic enclosure blocks direct eyelines, a twin-mirror system can redirect the actors’ view while the camera remains between them.**

### Section 6 — Engineering story

Create a quiet, full-screen cinematic section.

On-screen copy:

**The challenge was simple to describe and difficult to solve: build a large-format camera system capable of recording an entire dialogue-driven feature.**

Show three animated stat callouts:

- More than two million feet of film
- Filming across multiple countries
- A complete feature captured in large format

Do not attribute these claims to any person or organization.

---

## Section 7 — Interactive finale

Reassemble the camera and point it toward a live procedural 3D scene.

Create the scene entirely in code. Do not use video, trailer footage, copyrighted artwork, imported models, or stock assets.

Suggested scene:

- Moonlit sea
- Ancient wooden galley
- Low horizon
- Atmospheric fog
- Foreground rocks or rigging
- Clear depth between foreground, ship, and horizon

Keep the camera as the visual star. The scene exists to demonstrate the camera’s operation and framing.

### User controls

1. **Rack focus**
   - Shift focus between the foreground and the ship or horizon
   - Use realistic bokeh and a visible focus transition

2. **Frame the shot**
   - Allow pan and tilt
   - Add a subtle reticle
   - Include a horizon level

3. **Format comparison**
   - Toggle between a large, near-square frame and a conventional cropped frame
   - Show the difference side by side or as an overlay
   - Make the expanded field of view immediately understandable

4. **Recording behavior**
   - Recording tally light activates
   - Film-remaining counter decreases
   - Film transport animates
   - Synthesized shutter and film-running audio plays
   - Live viewfinder shows the captured composition

End card:

**THE LARGE-FORMAT CAMERA**

Closing line:

**A quiet tribute to the engineers who pushed photochemical cinema forward.**

---

## Design system

### Palette

- Near-black: `#0a0a0a`
- Bone white: `#f4f1ea`
- Film amber: `#e8a33d`
- Brushed metallic greys

### Typography

- Oversized condensed display headlines
- Clean sans-serif body text
- Strong scale contrast
- Minimal copy per section

### Motion

- Scroll-scrubbed and eased
- Scrolling down disassembles the camera
- Scrolling up reassembles it
- Gentle inertia
- No abrupt motion
- Thin film-strip progress indicator

### Copy rules

- Factual
- Plainly stated
- No jokes
- No exaggerated marketing language
- No names of people, companies, products, or films

---

## Technical and runtime requirements

- Native ES modules
- No build step
- Fully responsive
- Mobile-specific exploded-view layout
- Mobile-friendly finale controls
- Reduced-motion support
- Graceful graphics-capability detection
- Capped device-pixel ratio
- Pause rendering when the tab is hidden
- Smooth target performance
- Throttle heavy calculations
- Use level-of-detail techniques when zoomed out
- No generic card grids
- No stock imagery
- No glassmorphism
- No invented integrations
- No credentials, tokens, secrets, personal information, or external service identifiers

---

## Validation and iteration

The project will be judged first on:

1. The photorealism of the camera
2. The quality of the exploded-view sequence
3. The satisfaction of the interactive shooting finale
4. Runtime stability and responsiveness

After building:

1. Render the experience.
2. Capture screenshots of the output.
3. Inspect the camera in close-up.
4. Inspect it while disassembled.
5. Test mobile behavior.
6. Test reduced-motion behavior.
7. Fix anything that looks like a generic grey box, low-detail game prop, or unfinished prototype.
8. Complete at least three full self-review-and-improvement passes.

Do not return placeholders, incomplete sections, invented service calls, hidden fallback rendering, or code with console errors.

Return:

- Complete directly runnable code
- Clear file structure
- Brief launch instructions
- A short summary of the three self-review passes
